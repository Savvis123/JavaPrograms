package com.centurylink.statusmanager.runner;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import com.centurylink.statusmanager.extentReports.ExtentReportConfigurations;
import com.centurylink.statusmanager.mailUtilities.SendMailwithAttachment;
import com.centurylink.statusmanager.utilities.SeleniumDriver;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = "src/test/resources/features", plugin = { "json:target/RunCukes/cucumber.json", "pretty",
		"html:target/RunCukes/cucumber.html",
		"com.cucumber.listener.ExtentCucumberFormatter" }, glue = "com/centurylink/statusmanager/stepDefinitions", tags = {
				"@AutoDemo" }, monochrome = true

)

public class RunCukes extends AbstractTestNGCucumberTests {

	//static SeleniumDriver sd = new SeleniumDriver();
	//static SendMailwithAttachment mail = new SendMailwithAttachment();

	@BeforeSuite
	public static void setup() {

		ExtentReportConfigurations.initializereportConfig();

		SeleniumDriver.setupDriver();

	}

	@AfterSuite
	public static void teardown() {

		SeleniumDriver.tearDown();

		System.out.println("File name = " + ExtentReportConfigurations.Filename);
		System.out.println("Report name = " + ExtentReportConfigurations.reportName);
	}

}
