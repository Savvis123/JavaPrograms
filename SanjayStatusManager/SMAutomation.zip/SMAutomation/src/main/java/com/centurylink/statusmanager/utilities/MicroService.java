package com.centurylink.statusmanager.utilities;


public class MicroService {
	private String microservicename;
	private String microserstatus;
	private String microservicecode;
	private String microservicestatusmsg;
	private String microserviceduedate;
	private String microservicecompdate;
	private String microservicecomment;
	private String microservicenotBeforeDate;
	private String microservicecustomerCommitmentDate;
	
	
	
	public String getMicroservicename() {
		return microservicename;
	}
	public void setMicroservicename(String microservicename) {
		this.microservicename = microservicename;
		
	}
	
	public String getMicroserstatus() {
		return microserstatus;
		
	}
	public void setMicroserstatus(String microserstatus) {
		this.microserstatus = microserstatus;
	
	}
	
	
	public String getMicroservicecode() {
		return microservicecode;
	}
	public void setMicroservicecode(String microservicecode) {
		this.microservicecode = microservicecode;
	}
	
	
	public String getMicroservicestatusmsg() {
		return microservicestatusmsg;
	}
	public void setMicroservicestatusmsg(String microservicestatusmsg) {
		this.microservicestatusmsg = microservicestatusmsg;
	}
	public String getMicroserviceduedate() {
		return microserviceduedate;
	}
	public void setMicroserviceduedate(String microserviceduedate) {
		this.microserviceduedate = microserviceduedate;
	}
	public String getMicroservicecompdate() {
		return microservicecompdate;
	}
	public void setMicroservicecompdate(String microservicecompdate) {
		this.microservicecompdate = microservicecompdate;
	}
	public String getMicroservicecomment() {
		return microservicecomment;
	}
	public void setMicroservicecomment(String microservicecomment) {
		this.microservicecomment = microservicecomment;
	}
	
	
	
	
	public String getMicroservicenotbeforedate() {
		return microservicenotBeforeDate;
	}
	public void setMicroservicenotbeforedate(String microservicenotBeforeDate) {
		this.microservicenotBeforeDate = microservicenotBeforeDate;
		
	}

	public String getMicroservicecustomercommitmentdate() {
		return microservicecustomerCommitmentDate;
	}
	public void setMicroservicecustomercommitmentdate(String microservicecustomerCommitmentDate) {
		this.microservicecustomerCommitmentDate = microservicecustomerCommitmentDate;
		
	}
	
}


