package com.centurylink.statusmanager.mailUtilities;

public class emailIDTO {

	protected static String TOList = "sanjay.kemmanagudde@centurylink.com" ;
	
	protected static String CcList = "sanjay.kemmanagudde@centurylink.com" ;
	
	// Koteswara.Kadali@CenturyLink.com
}
