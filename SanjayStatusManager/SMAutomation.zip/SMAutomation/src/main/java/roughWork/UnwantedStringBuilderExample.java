package roughWork;

public class UnwantedStringBuilderExample {


/*			if (CustomListeners.status.equalsIgnoreCase("PASS")) {

				m.append("Hi,").append(System.lineSeparator()).append(System.lineSeparator());
				m.append("<p>").append(
						reportMessage)
						.append("</p>");
				m.append(System.lineSeparator());
				m.append(System.lineSeparator());
				m.append(System.lineSeparator());
				m.append("<body>");

				m.append("<div style='margin-left:10px; margin-right:10px; padding:10px 10px 10px 10px;'>");
				m.append(
						"<table style='border-color:#114411; border:1px solid; border-collapse:collapse; overflow:scroll;'>");
				m.append(
						"<tr style='border:1px solid; border-collapse:collapse; font-weight:bold; vertical-align:middle; text-align:center;'>");

				m.append("<th style='border:1px solid; padding:10px 10px 10px 10px;'>Test Report Name</th>");
				m.append(
						"<th style='border:1px solid; border-collapse:collapse;padding:10px 10px 10px 10px;'>Automation Suite Result</th>");
				m.append(
						"<th style='border:1px solid; border-collapse:collapse;padding:10px 10px 10px 10px;'>Browser</th>");
				m.append(
						"<th style='border:1px solid; border-collapse:collapse;padding:10px 10px 10px 10px;'>Test Environment</th>");
				m.append(
						"<th style='border:1px solid; border-collapse:collapse;padding:10px 10px 10px 10px;'>Execution Time</th>");

				m.append("</tr>");

				m.append(
						"<tr style='border:1px solid; border-collapse:collapse; vertical-align:middle; text-align:center;'>");
				m.append("<td style='border:1px solid; padding:10px 10px 10px 10px;'>").append(ReportInfo)
						.append("</td>");
				m.append(
						"<td style='border:1px solid; border-collapse:collapse; padding:10px 10px 10px 10px; color:MediumSeaGreen'>")
						.append(TestStatus).append("</td>");
				m.append("<td style='border:1px solid; border-collapse:collapse; padding:10px 10px 10px 10px;'>")
						.append(BrowserInfo).append("</td>");
				m.append("<td style='border:1px solid; border-collapse:collapse; padding:10px 10px 10px 10px;'>")
						.append(EnvInfo).append("</td>");
				m.append("<td style='border:1px solid; border-collapse:collapse; padding:10px 10px 10px 10px;'>")
						.append(ExecutionTime).append("</td>");

				m.append("</tr>");

				m.append("</table></div>");

				m.append(System.lineSeparator()).append(System.lineSeparator());
				m.append(System.lineSeparator());
				m.append("<p>").append("Thank You.").append("</p>");

			} else if (CustomListeners.status.equalsIgnoreCase("FAIL")) {

				m.append("Hi,").append(System.lineSeparator()).append(System.lineSeparator());
				m.append("<p>").append(
						reportMessage)
						.append("</p>");
				m.append(System.lineSeparator());
				m.append(System.lineSeparator());
				m.append(System.lineSeparator());
				m.append("<body>");

				m.append("<div style='margin-left:10px; margin-right:10px; padding:10px 10px 10px 10px;'>");
				m.append(
						"<table style='border-color:#114411; border:1px solid; border-collapse:collapse; overflow:scroll;'>");
				m.append(
						"<tr style='border:1px solid; border-collapse:collapse; font-weight:bold; vertical-align:middle; text-align:center;'>");

				m.append("<th style='border:1px solid; padding:10px 10px 10px 10px;'>Test Report Name</th>");
				m.append(
						"<th style='border:1px solid; border-collapse:collapse;padding:10px 10px 10px 10px;'>Automation Suite Result</th>");
				m.append(
						"<th style='border:1px solid; border-collapse:collapse;padding:10px 10px 10px 10px;'>Browser</th>");
				m.append(
						"<th style='border:1px solid; border-collapse:collapse;padding:10px 10px 10px 10px;'>Test Environment</th>");
				m.append(
						"<th style='border:1px solid; border-collapse:collapse;padding:10px 10px 10px 10px;'>Execution Time</th>");

				m.append("</tr>");

				m.append(
						"<tr style='border:1px solid; border-collapse:collapse; vertical-align:middle; text-align:center;'>");
				m.append("<td style='border:1px solid; padding:10px 10px 10px 10px;'>").append(ReportInfo)
						.append("</td>");
				m.append(
						"<td style='border:1px solid; border-collapse:collapse; padding:10px 10px 10px 10px; color:red'>")
						.append(TestStatus).append("</td>");
				m.append("<td style='border:1px solid; border-collapse:collapse; padding:10px 10px 10px 10px;'>")
						.append(BrowserInfo).append("</td>");
				m.append("<td style='border:1px solid; border-collapse:collapse; padding:10px 10px 10px 10px;'>")
						.append(EnvInfo).append("</td>");
				m.append("<td style='border:1px solid; border-collapse:collapse; padding:10px 10px 10px 10px;'>")
						.append(ExecutionTime).append("</td>");

				m.append("</tr>");

				m.append("</table></div>");

				m.append(System.lineSeparator()).append(System.lineSeparator());
				m.append(System.lineSeparator());
				m.append("<p>").append("Thank You.").append("</p>");

			}

			*/
			
			//  =================================================
	
}
